# LixiPy
Packaged used for the Python Processing applied at the Lixi EEG Project
