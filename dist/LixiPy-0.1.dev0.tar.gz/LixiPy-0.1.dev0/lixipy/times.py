if __name__ == "__main__":
    import basics
    import ops
    import freqs
    import intels    
else:
    from lixipy import basics
    from lixipy import ops
    from lixipy import freqs
    from lixipy import intels