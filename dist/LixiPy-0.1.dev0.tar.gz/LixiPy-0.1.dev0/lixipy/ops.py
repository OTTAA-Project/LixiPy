if __name__ == "__main__":
    import basics
    import times
    import freqs
    import intels    
else:
    from lixipy import basics
    from lixipy import times
    from lixipy import freqs
    from lixipy import intels