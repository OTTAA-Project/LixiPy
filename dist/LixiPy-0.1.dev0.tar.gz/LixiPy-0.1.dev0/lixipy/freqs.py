if __name__ == "__main__":
    import basics
    import ops
    import times
    import intels    
else:
    from lixipy import basics
    from lixipy import ops
    from lixipy import times
    from lixipy import intels