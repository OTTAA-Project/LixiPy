if __name__ == "__main__":
    import ops
    import times
    import freqs
    import intels    
else:
    from lixipy import ops
    from lixipy import times
    from lixipy import freqs
    from lixipy import intels